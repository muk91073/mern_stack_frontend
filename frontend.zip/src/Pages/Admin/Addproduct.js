import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api_configs } from "../../Apiconfig/apiconfig";

const Addproduct = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    product_name: "",
    image: "",
    product_code: "",
    price: "",
    category: "",
    manufacture_date: "",
    expiry_date: "",
    owner: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const addproductApi = async () => {
    try {
        console.log("rrrrrr")
      const res = await axios({
        method: "POST",
        url: api_configs.addProduct,
        data: formData,
      });
      console.log("redsss", res);
      if (res.data.responseCode === 200) {
        alert(res.data.message);
        navigate("/productlist");
      } else {
        alert(res.data.message);
      }
    } catch (error) {
      console.error("Error in product:", error);
    //   alert("Something went wrong!");
    }
  };

  return (
    <>
      <div style={{ paddingTop: "50px" }}>
        <div className="mainlogincss">
          <div className="innercss">
            <h4>Add Product</h4>
            <div className="textbox">
              <div>
                <h6>Enter the product name</h6>
                <input
                  type="text"
                  placeholder="Enter the name"
                  name="product_name"
                  value={formData.product_name}
                  onChange={handleChange}
                />
              </div>
              <div>
                <h6>Select image</h6>
                <input
                  placeholder="Enter the image"
                  name="image" 
                  type="file"
                  value={formData.image} 
                  onChange={handleChange} 
                />
              </div>
              <div>
                <h6>Enter the product_code</h6>
                <input
                  type="product_code"
                  placeholder="Enter the product_code"
                  name="product_code"
                  value={formData.product_code}
                  onChange={handleChange}
                />
              </div>
              <div>
                <h6>Enter the price</h6>
                <input
                  type="price"
                  placeholder="Enter the price"
                  name="price"
                  value={formData.price}
                  onChange={handleChange}
                />
              </div>
              <div>
                <h6>Enter the category</h6>
                <input
                  type="category"
                  placeholder="Enter the category"
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                />
              </div>
              <div>
                <h6>Enter the manufacture_date</h6>
                <input
                  type="date"
                  placeholder="Enter the manufacture_date"
                  name="manufacture_date"
                  value={formData.manufacture_date}
                  onChange={handleChange}
                />
              </div>
              <div>
                <h6>Enter the expiry_date</h6>
                <input
                  type="date"
                  placeholder="Enter the expiry_date"
                  name="expiry_date"
                  value={formData.expiry_date}
                  onChange={handleChange}
                />
              </div>
              <div>
                <h6>Enter the Owner</h6>
                <input
                  type="Owner"
                  placeholder="Enter the Owner"
                  name="owner"
                  value={formData.owner}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="btncss">
              <button onClick={addproductApi}>Add product</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Addproduct;
