import axios from "axios";
import React, { useEffect, useState } from "react";
import { api_configs } from "../../Apiconfig/apiconfig";

const Productlist = () => {
  const [products, setProducts] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [newPrice, setNewPrice] = useState("");
  const [searchproducts, setSearchproducts] = useState("");

  const productList = async () => {
    try {
      const res = await axios({
        method: "GET",
        url: api_configs.productList,
        params: {
          product_name: searchproducts,
        },
      });
      if (res.data.responseCode === 200) {
        setProducts(res.data.product);
      } else {
        alert(res.data.message);
      }
    } catch (error) {
      console.log("Error fetching product list:", error);
    }
  };

  useEffect(() => {
    productList();
  }, [searchproducts]);

  const handleEditClick = (product) => {
    setSelectedProduct(product);
    setNewPrice(product.price);
    setIsModalOpen(true);
  };

  // Close modal
  const closeModal = () => {
    setIsModalOpen(false);
  };

  const updateProductPrice = async () => {
    const minPrice = selectedProduct?.price * 0.9;
    const maxPrice = selectedProduct?.price * 1.1;

    if (newPrice < minPrice || newPrice > maxPrice) {
      alert(`Price must be between ${minPrice.toFixed(2)} and ${maxPrice.toFixed(2)}.`);
      return;
    }

    try {
      const res = await axios({
        method: "PUT",
        
        url: `${api_configs.updateProductPrice}?_id=${selectedProduct._id}&price=${newPrice}`, 
      });

      if (res.data.responseCode === 200) {
        alert("Price updated successfully");
        setIsModalOpen(false);
        productList(); 
      } else {
        alert(res.data.message);
      }
    } catch (error) {
      console.log("Error updating price:", error);
    }
  };

  return (
    <>
      <div style={{ padding: "20px" }}>
        <h5>Product List</h5>
        <div className="searchdiv">
          <h6>Search &nbsp;</h6>
          <div className="searchbox">
            <input
              type="search"
              placeholder="Filter by category or name"
              value={searchproducts}
              onChange={(e) => setSearchproducts(e.target.value)}
            />
          </div>
        </div>

        <table border="1" style={{ width: "100%", padding: "10px" }}>
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Product Code</th>
              <th>Price</th>
              <th>Category</th>
              <th>Image</th>
              <th>Manufacture Date</th>
              <th>Expiry Date</th>
              <th>Owner</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.length > 0 ? (
              products.map((product, index) => (
                <tr key={index}>
                  <td>{product.product_name}</td>
                  <td>{product.product_code}</td>
                  <td>{product.price}</td>
                  <td>{product.category}</td>
                  <td>{product.image}</td>
                  <td>{product.manufacture_date}</td>
                  <td>{product.expiry_date}</td>
                  <td>{product.Owner}</td>
                  <td>
                    <button onClick={() => handleEditClick(product)}>
                      Edit
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="9" style={{ textAlign: "center" }}>
                  No products available.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal for editing price */}
      {isModalOpen && selectedProduct && (
        <div className="modal" style={modalStyles}>
          <div className="modal-content" style={modalContentStyles}>
            <h5>Edit Product Price</h5>
            <div>
              <h6>
                Product Name: <b>{selectedProduct?.product_name}</b>
                <p>
                  Price range: -10% to +10% (i.e., if the price of the product is 100, then you can only set it
                  between 90 and 110).
                </p>
              </h6>
            </div>
            <div>
              <h6 style={{ textAlign: "start" }}>New Price:</h6>
              <input
                type="number"
                value={newPrice}
                onChange={(e) => setNewPrice(e.target.value)}
                style={inputStyles}
              />
            </div>
            <div>
              <button style={buttonbox} onClick={updateProductPrice}>
                Submit
              </button>{" "}
              &nbsp;
              <button style={crossbtn} onClick={closeModal}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

const modalStyles = {
  position: "fixed",
  top: 0,
  left: 0,
  width: "100%",
  height: "100%",
  backgroundColor: "rgba(0,0,0,0.5)",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  zIndex: 1000,
};

const buttonbox = {
  padding: "8px 20px",
  fontSize: "16px",
  backgroundColor: "#4CAF50",
  color: "white",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer",
  transition: "background-color 0.3s, transform 0.2s",
};

const crossbtn = {
  padding: "8px 20px",
  fontSize: "16px",
  backgroundColor: "rgb(155, 22, 22)",
  color: "white",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer",
  transition: "background-color 0.3s, transform 0.2s",
};

const modalContentStyles = {
  backgroundColor: "white",
  padding: "20px",
  borderRadius: "8px",
  width: "400px",
  textAlign: "center",
};

const inputStyles = {
  padding: "8px",
  marginBottom: "10px",
  width: "96%",
};

export default Productlist;
