import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api_configs } from "../../Apiconfig/apiconfig";

const Signup = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value, 
    });
  };

  const registerApi = async () => {
    try {
      const res = await axios({
        method: "POST",
        url: api_configs.signUp,
        data: formData, 
      });

      if (res.data.responseCode === 200) {
        alert(res.data.message);
        navigate("/login"); 
      } else {
        alert(res.data.message);
      }
    } catch (error) {
      console.error("Error in signup:", error);
      alert("Something went wrong! Please try again.");
    }
  };

  return (
    <>
      <div style={{ paddingTop: "50px" }}>
        <div className="mainlogincss">
          <div className="innercss">
            <h4>Registration</h4>
            <div className="textbox">
              <div>
                <h6>Enter the name</h6>
                <input
                  type="text"
                  placeholder="Enter the name"
                  name="name" 
                  value={formData.name}
                  onChange={handleChange} 
                />
              </div>
              <div>
                <h6>Enter the email</h6>
                <input
                  type="email"
                  placeholder="Enter the email"
                  name="email" 
                  value={formData.email} 
                  onChange={handleChange} 
                />
              </div>
              <div>
                <h6>Enter the password</h6>
                <input
                  type="password"
                  placeholder="Enter the password"
                  name="password" 
                  value={formData.password} 
                  onChange={handleChange} 
                />
              </div>
            </div>
            <div>
              <p>
                Already have an account?{" "}
                <span
                  onClick={() => navigate("/login")}
                  style={{ cursor: "pointer", color: "green" }}
                >
                  Login
                </span>
              </p>
            </div>
            <div className="btncss">
              <button onClick={registerApi}>Submit</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Signup;
