import axios from "axios";
import React,{useState} from "react";
import { useNavigate } from "react-router-dom";
import { api_configs } from "../../Apiconfig/apiconfig";
const Login = () => {
    const navigate = useNavigate()
  
     const [formData, setFormData] = useState({     
        email: "",
        password: "",
      });

      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
          ...formData,
          [name]: value, 
        });
      };


      const loginApi = async () => {
        try {
          const res = await axios({
            method: "POST",
            url: api_configs.login,
            data: formData, 
          });
    
          if (res.data.responseCode === 200) {
            console.log(res.data.token)
            localStorage.setItem("token",res.data.token)
            alert(res.data.message);
            navigate("/addproduct"); 

          } else {
            alert(res.data.message);
          }
        } catch (error) {
          console.error("Error in signup:", error);
          alert("Something went wrong! Please try again.");
        }
      };
  return (
    <>
      <div style={{ paddingTop: "50px" }}>
        <div className="mainlogincss">
          <div className="innercss">
            <h4>Login</h4>
            <div className="textbox" >
              <div >
                <h6>Enter the email</h6>
                <input placeholder="Enter the email" 
                  name="email" 
                  value={formData.email} 
                  onChange={handleChange} 
                />
              </div>
              <div>
                <h6>Enter the password</h6>
                <input placeholder="Enter the password" 
                  name="password" 
                  value={formData.password} 
                  onChange={handleChange} 
                />
              </div>
            </div>
            <div>
                <p>Allready have an account <span onClick={()=>navigate("/")} style={{cursor:"pointer",color:"green"}}>Registration</span></p>
            </div>
            <div className="btncss">
                <button onClick={loginApi}>Submit</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
