import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router , Routes , Route } from 'react-router-dom';
import Login from './Pages/Auth/Login';
import Signup from './Pages/Auth/Signup';
import Addproduct from './Pages/Admin/Addproduct';
import Productlist from './Pages/Admin/Productlist';

function App() {
  return (
    <div className="App">
     <Router>
      <Routes>
        <Route path='/' element={<Signup />} />
        <Route path='/login' element={<Login />} />
        <Route path='/addproduct' element={<Addproduct />} />
        <Route path='/productlist' element={<Productlist />} />
      </Routes>
     </Router>
    </div>
  );
}

export default App;
