
export const server_base_url = "http://localhost:5000";
let version = `${server_base_url}/api/auth`;
let user = `${version}`;

export const api_configs = {
    signUp: `${user}/signUp`,
    login: `${user}/login`,
    addProduct: `${user}/addProduct`,
    productList:`${user}/productList`,
    updateProductPrice:`${user}/updateProductPrice`,
};